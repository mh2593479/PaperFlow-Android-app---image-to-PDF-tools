package com.paperflow.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.io.File
import java.io.FileOutputStream

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                PaperFlowScreen(
                    onMakePdf = { uris ->
                        try {
                            val outDir = File(cacheDir, "exports").apply { mkdirs() }
                            val outFile = File(outDir, "PaperFlow-${System.currentTimeMillis()}.pdf")
                            createPdf(uris, outFile)
                            Toast.makeText(this, "PDF created: ${outFile.name}. Find it in app cache; sharing/export is coming next.", Toast.LENGTH_LONG).show()
                        } catch (e: Exception) {
                            Toast.makeText(this, "Could not create PDF: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    }
                )
            }
        }
    }

    private fun createPdf(uris: List<Uri>, output: File) {
        require(uris.isNotEmpty()) { "Choose at least one image first." }
        val document = PdfDocument()
        try {
            uris.forEachIndexed { index, uri ->
                val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                    ?: throw IllegalArgumentException("Could not read selected image.")
                val maxSide = 1400
                val ratio = minOf(1f, maxSide.toFloat() / maxOf(bitmap.width, bitmap.height))
                val width = (bitmap.width * ratio).toInt().coerceAtLeast(1)
                val height = (bitmap.height * ratio).toInt().coerceAtLeast(1)
                val scaled = if (width != bitmap.width || height != bitmap.height) {
                    Bitmap.createScaledBitmap(bitmap, width, height, true).also { if (it != bitmap) bitmap.recycle() }
                } else bitmap
                val pageInfo = PdfDocument.PageInfo.Builder(width, height, index + 1).create()
                val page = document.startPage(pageInfo)
                page.canvas.drawBitmap(scaled, 0f, 0f, null)
                document.finishPage(page)
                scaled.recycle()
            }
            FileOutputStream(output).use { document.writeTo(it) }
        } finally {
            document.close()
        }
    }
}

@Composable
private fun PaperFlowScreen(onMakePdf: (List<Uri>) -> Unit) {
    var selectedUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { selectedUris = it }

    Scaffold { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text("PaperFlow", style = MaterialTheme.typography.headlineLarge)
                Text("Simple tools for images and PDF documents.")
            }
            item {
                Card {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Images to PDF", style = MaterialTheme.typography.titleLarge)
                        Text("Choose pictures, arrange their order in the picker, then create a PDF.")
                        Button(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                            Text("Choose images")
                        }
                        Text("${selectedUris.size} image(s) selected")
                        Button(
                            onClick = { onMakePdf(selectedUris) },
                            enabled = selectedUris.isNotEmpty(),
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Create PDF") }
                    }
                }
            }
            item {
                Text("Quick tools", style = MaterialTheme.typography.titleLarge)
            }
            itemsIndexed(listOf(
                "Scan Document — planned",
                "Merge PDF — planned",
                "Compress PDF — planned",
                "Extract Text (OCR) — planned",
                "Split PDF — planned",
                "Reorder pages — planned"
            )) { _, label ->
                Card(Modifier.fillMaxWidth()) {
                    Text(label, Modifier.padding(16.dp))
                }
            }
            item {
                Text(
                    "Starter build: Images to PDF is implemented. Other tools are listed as planned and are not implemented yet.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
