# PaperFlow Android starter

This is a fresh starter project created because the original complete project files and ZIP could not be recovered from the visible conversation.

## Included
- Native Android app using Kotlin and Jetpack Compose
- Select multiple images
- Create a basic PDF from the selected images
- GitHub Actions workflow to build a debug APK and publish it as a downloadable artifact

## Not included yet
Scan, merge, compress, OCR, split, page reordering, ads/AdMob, release signing, and saving/sharing the generated PDF through Android's document picker are not implemented in this starter.

## Build on GitHub using a phone
1. Create a new empty repository on GitHub.
2. Upload the contents of this project folder (not the ZIP file) to the repository.
3. Open the Actions tab and run "Build PaperFlow APK", or push to `main`.
4. Open the completed workflow run and download the `PaperFlow-debug-apk` artifact.
5. The artifact is a ZIP containing `app-debug.apk`; extract it on your phone, then install the APK.

The build workflow has not been executed here. GitHub Actions must run it to verify the build.
